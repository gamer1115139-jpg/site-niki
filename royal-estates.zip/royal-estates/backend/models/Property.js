const mongoose = require("mongoose");

const PropertySchema = new mongoose.Schema({
  title: String,
  city: String,
  price: Number,
  rooms: Number,
  image: String,
  video: String,
  description: String
});

module.exports = mongoose.model("Property", PropertySchema);