const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/realestate");

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
const propertyRoutes = require("./routes/propertyRoutes");
app.use("/api/properties", propertyRoutes);