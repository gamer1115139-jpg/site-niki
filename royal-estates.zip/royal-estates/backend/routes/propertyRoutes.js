const express = require("express");
const router = express.Router();
const Property = require("../models/Property");

// گرفتن همه ملک‌ها
router.get("/", async (req, res) => {
  const data = await Property.find();
  res.json(data);
});

// اضافه کردن ملک
router.post("/", async (req, res) => {
  const newProperty = new Property(req.body);
  await newProperty.save();
  res.json(newProperty);
});

module.exports = router;